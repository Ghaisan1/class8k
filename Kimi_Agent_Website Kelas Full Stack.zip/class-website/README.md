# Class Website - Full Stack Web Application

Website kelas modern dengan sistem admin lengkap, built dengan React, Node.js, Express, dan MongoDB.

## Fitur

### Frontend
- **React + TypeScript + Vite** - Modern frontend stack
- **Tailwind CSS** - Styling yang responsif dan modern
- **Framer Motion** - Animasi smooth dan transisi halus
- **React Router** - Navigasi client-side
- **Responsive Design** - Mobile-friendly

### Backend
- **Node.js + Express** - REST API
- **MongoDB + Mongoose** - Database
- **JWT Authentication** - Sistem login aman
- **Multer** - File upload dengan validasi
- **Bcrypt** - Password encryption

### Fitur Website
1. **Home Page**
   - Hero section dengan nama kelas dan deskripsi
   - Background image/video yang dapat dikustomisasi
   - Background music dengan play/pause control

2. **Students Page**
   - Grid card 40 siswa dengan foto, nama, dan quote
   - Section khusus wali kelas yang lebih menonjol

3. **Gallery Page**
   - Grid foto modern
   - Modal preview untuk melihat foto besar

4. **Social Links**
   - Icon Instagram, TikTok, YouTube
   - Link dapat dikonfigurasi via admin

5. **Admin Dashboard**
   - CRUD Siswa (Create, Read, Update, Delete)
   - CRUD Wali Kelas
   - CRUD Galeri
   - CRUD Social Links
   - Pengaturan Website (Hero image, background music, dll)

## Struktur Database

### Collections

1. **admins**
   - username: String
   - password: String (hashed)

2. **students**
   - fullName: String
   - photo: String (URL)
   - quote: String
   - bio: String
   - order: Number

3. **teachers**
   - fullName: String
   - photo: String (URL)
   - subject: String
   - quote: String
   - bio: String

4. **galleries**
   - title: String
   - image: String (URL)
   - description: String
   - category: String
   - order: Number

5. **socials**
   - platform: String (instagram, tiktok, youtube, twitter, facebook)
   - url: String
   - isActive: Boolean

6. **settings**
   - className: String
   - classDescription: String
   - heroImage: String
   - heroVideo: String
   - backgroundMusic: String
   - musicTitle: String
   - primaryColor: String
   - secondaryColor: String

## Cara Menjalankan

### Prerequisites
- Node.js 18+
- MongoDB (local atau cloud)

### Setup Backend

```bash
cd backend
npm install
```

Buat file `.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/class_website
JWT_SECRET=your_secret_key_here
NODE_ENV=development
```

Jalankan server:
```bash
npm run dev
```

Server akan berjalan di `http://localhost:5000`

Default admin credentials:
- Username: `admin`
- Password: `admin123`

### Setup Frontend

```bash
cd frontend
npm install
```

Jalankan development server:
```bash
npm run dev
```

Frontend akan berjalan di `http://localhost:3000`

## Deployment

### Backend (Railway/Render/Heroku)
1. Push code ke GitHub
2. Connect repository ke platform deployment
3. Set environment variables
4. Deploy

### Frontend (Vercel/Netlify)
1. Build project: `npm run build`
2. Deploy folder `dist` ke platform
3. Set environment variables

## Environment Variables

### Backend
- `PORT` - Port server (default: 5000)
- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Secret key untuk JWT
- `NODE_ENV` - Environment (development/production)

### Frontend
- `VITE_API_URL` - URL backend API

## Validasi Upload File

### Gambar
- Format yang diterima: jpeg, jpg, png, webp, gif
- Max size: 10MB

### Audio
- Format yang diterima: mp3, wav, ogg, m4a
- Max size: 10MB

## Credit

Website developed by **Ghaisan Athaillah Fuadi**

## License

MIT License
