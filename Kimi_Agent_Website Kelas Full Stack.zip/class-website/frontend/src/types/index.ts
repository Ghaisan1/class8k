export interface Student {
  _id: string;
  fullName: string;
  photo: string;
  quote: string;
  bio?: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface Teacher {
  _id: string;
  fullName: string;
  photo: string;
  subject: string;
  quote: string;
  bio?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GalleryItem {
  _id: string;
  title: string;
  image: string;
  description?: string;
  category: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

export interface SocialLink {
  _id: string;
  platform: 'instagram' | 'tiktok' | 'youtube' | 'twitter' | 'facebook';
  url: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Settings {
  _id: string;
  className: string;
  classDescription: string;
  heroImage: string | null;
  heroVideo: string | null;
  backgroundMusic: string | null;
  musicTitle: string;
  primaryColor: string;
  secondaryColor: string;
  createdAt: string;
  updatedAt: string;
}

export interface Admin {
  _id: string;
  username: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  admin: Admin | null;
  token: string | null;
}

export interface LoginCredentials {
  username: string;
  password: string;
}
