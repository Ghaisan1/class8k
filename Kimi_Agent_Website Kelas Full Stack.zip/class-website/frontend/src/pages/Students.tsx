import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Quote, User, GraduationCap } from 'lucide-react';
import { studentsAPI, teacherAPI } from '@/services/api';
import type { Student, Teacher } from '@/types';

const Students: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [teacher, setTeacher] = useState<Teacher | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [studentsRes, teacherRes] = await Promise.all([
        studentsAPI.getAll(),
        teacherAPI.get(),
      ]);
      setStudents(studentsRes.data);
      setTeacher(teacherRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-20">
      <section className="section-padding bg-gradient-to-b from-navy-900 to-navy-950">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">Kenalan dengan <span className="gradient-text">Kami</span></h1>
            <p className="text-gray-400 max-w-2xl mx-auto">Berkenalan dengan wali kelas dan 40 siswa yang membuat kelas ini istimewa.</p>
          </motion.div>
        </div>
      </section>

      {teacher && (
        <section className="section-padding bg-navy-950">
          <div className="max-w-7xl mx-auto">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/10 text-yellow-400 mb-4">
                <GraduationCap className="w-5 h-5" />
                <span className="text-sm font-medium">Wali Kelas</span>
              </div>
              <h2 className="text-3xl font-bold">Pemimpin Kami</h2>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="max-w-2xl mx-auto">
              <div className="glass rounded-2xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/10 rounded-full blur-3xl" />
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl" />
                <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                  <div className="relative">
                    <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-yellow-500/30">
                      <img src={teacher.photo} alt={teacher.fullName} className="w-full h-full object-cover" />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center">
                      <GraduationCap className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <div className="text-center md:text-left flex-1">
                    <h3 className="text-2xl font-bold mb-2">{teacher.fullName}</h3>
                    <p className="text-yellow-400 font-medium mb-4">{teacher.subject}</p>
                    <div className="flex items-start gap-2 text-gray-300 italic">
                      <Quote className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-1" />
                      <p>{teacher.quote}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      )}

      <section className="section-padding bg-navy-900">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-400 mb-4">
              <User className="w-5 h-5" />
              <span className="text-sm font-medium">Siswa</span>
            </div>
            <h2 className="text-3xl font-bold mb-2">Anggota Kelas</h2>
            <p className="text-gray-400">Total: {students.length} siswa</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {students.map((student, index) => (
              <motion.div key={student._id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: index * 0.05 }}
                className="group glass rounded-2xl overflow-hidden hover-lift">
                <div className="overflow-hidden aspect-[3/4]">
                  <img src={student.photo} alt={student.fullName} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                </div>
                <div className="p-5">
                  <h3 className="text-lg font-semibold mb-2 group-hover:text-blue-400 transition-colors">{student.fullName}</h3>
                  <div className="flex items-start gap-2">
                    <Quote className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-gray-400 italic line-clamp-2">{student.quote}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Students;
