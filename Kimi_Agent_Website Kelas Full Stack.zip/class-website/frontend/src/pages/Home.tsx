import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Users, Image, Sparkles } from 'lucide-react';
import { settingsAPI } from '@/services/api';
import SocialLinks from '@/components/SocialLinks';
import type { Settings } from '@/types';

const Home: React.FC = () => {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await settingsAPI.get();
      setSettings(response.data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          {settings?.heroImage ? (
            <img src={settings.heroImage} alt="Hero" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-navy-900 via-navy-950 to-black" />
          )}
          <div className="absolute inset-0 bg-black/50" />
          <div className="absolute inset-0 grid-pattern opacity-30" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
            <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm mb-6">
              <Sparkles className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-gray-200">Selamat Datang</span>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6">
              {settings?.className || 'Kelas XII IPA 1'}
            </motion.h1>

            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.4 }}
              className="text-lg sm:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              {settings?.classDescription || 'Website kelas yang dibuat untuk mengenang momen-momen indah bersama teman-teman sekelas.'}
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.5 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
              <a href="/students" className="flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-600 rounded-full font-medium transition-colors">
                <Users className="w-5 h-5" />Lihat Siswa
              </a>
              <a href="/gallery" className="flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-full font-medium transition-colors">
                <Image className="w-5 h-5" />Galeri
              </a>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.6 }}>
              <SocialLinks />
            </motion.div>
          </motion.div>
        </div>

        <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.8 }}
          onClick={() => document.getElementById('content')?.scrollIntoView({ behavior: 'smooth' })}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 hover:text-white">
          <motion.div animate={{ y: [0, 10, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
            <ChevronDown className="w-8 h-8" />
          </motion.div>
        </motion.button>
      </section>

      <section id="content" className="section-padding bg-navy-950">
        <div className="max-w-7xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Jelajahi <span className="gradient-text">Website Kami</span></h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Temukan berbagai fitur menarik yang kami sediakan.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Users, title: 'Daftar Siswa', description: 'Lihat profil lengkap dari 40 siswa kelas kami.', link: '/students', color: 'from-blue-500 to-cyan-500' },
              { icon: Image, title: 'Galeri Kenangan', description: 'Jelajahi koleksi foto-foto kenangan indah.', link: '/gallery', color: 'from-purple-500 to-pink-500' },
              { icon: Sparkles, title: 'Momen Spesial', description: 'Setiap momen bersama adalah kenangan berharga.', link: '/gallery', color: 'from-yellow-500 to-orange-500' },
            ].map((feature, index) => (
              <motion.a key={feature.title} href={feature.link} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group glass rounded-2xl p-8 hover-lift">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.a>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
