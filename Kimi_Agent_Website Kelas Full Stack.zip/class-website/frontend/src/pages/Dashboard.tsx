import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Users, Image, Settings as SettingsIcon, Link, LogOut, Plus, Edit, Trash2, X, Music } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { studentsAPI, teacherAPI, galleryAPI, socialAPI, settingsAPI } from '@/services/api';
import type { Student, Teacher, GalleryItem, SocialLink, Settings } from '@/types';
import toast from 'react-hot-toast';

type TabType = 'students' | 'teacher' | 'gallery' | 'social' | 'settings';

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('students');
  const navigate = useNavigate();
  const { logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate('/');
    toast.success('Logged out');
  };

  const tabs = [
    { id: 'students' as TabType, label: 'Siswa', icon: Users },
    { id: 'teacher' as TabType, label: 'Wali Kelas', icon: LogOut },
    { id: 'gallery' as TabType, label: 'Galeri', icon: Image },
    { id: 'social' as TabType, label: 'Sosial', icon: Link },
    { id: 'settings' as TabType, label: 'Pengaturan', icon: SettingsIcon },
  ];

  return (
    <div className="min-h-screen pt-20 pb-20 bg-navy-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Dashboard Admin</h1>
            <p className="text-gray-400">Kelola konten website</p>
          </div>
          <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 bg-red-500/80 hover:bg-red-600 rounded-lg text-white">
            <LogOut className="w-4 h-4" />Logout
          </button>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap gap-2 mb-8">
          {tabs.map((tab) => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${activeTab === tab.id ? 'bg-blue-500 text-white' : 'bg-white/5 text-gray-300 hover:bg-white/10'}`}>
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {activeTab === 'students' && <StudentsTab />}
          {activeTab === 'teacher' && <TeacherTab />}
          {activeTab === 'gallery' && <GalleryTab />}
          {activeTab === 'social' && <SocialTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </motion.div>
      </div>
    </div>
  );
};

const StudentsTab: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [formData, setFormData] = useState({ fullName: '', quote: '', bio: '', photo: null as File | null });

  useEffect(() => { fetchStudents(); }, []);

  const fetchStudents = async () => {
    try {
      const response = await studentsAPI.getAll();
      setStudents(response.data);
    } catch (error) { toast.error('Failed to fetch students'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = new FormData();
    data.append('fullName', formData.fullName);
    data.append('quote', formData.quote);
    if (formData.bio) data.append('bio', formData.bio);
    if (formData.photo) data.append('photo', formData.photo);
    try {
      if (editingStudent) {
        await studentsAPI.update(editingStudent._id, data);
        toast.success('Student updated');
      } else {
        await studentsAPI.create(data);
        toast.success('Student created');
      }
      setIsModalOpen(false);
      setEditingStudent(null);
      setFormData({ fullName: '', quote: '', bio: '', photo: null });
      fetchStudents();
    } catch (error) { toast.error('Failed to save student'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this student?')) return;
    try {
      await studentsAPI.delete(id);
      toast.success('Student deleted');
      fetchStudents();
    } catch (error) { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Daftar Siswa ({students.length})</h2>
        <button onClick={() => { setEditingStudent(null); setFormData({ fullName: '', quote: '', bio: '', photo: null }); setIsModalOpen(true); }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white">
          <Plus className="w-4 h-4" />Tambah
        </button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {students.map((student) => (
          <div key={student._id} className="glass rounded-xl overflow-hidden">
            <div className="aspect-square"><img src={student.photo} alt={student.fullName} className="w-full h-full object-cover" /></div>
            <div className="p-4">
              <h3 className="font-semibold mb-1">{student.fullName}</h3>
              <p className="text-sm text-gray-400 line-clamp-2">{student.quote}</p>
              <div className="flex gap-2 mt-3">
                <button onClick={() => { setEditingStudent(student); setFormData({ fullName: student.fullName, quote: student.quote, bio: student.bio || '', photo: null }); setIsModalOpen(true); }}
                  className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-blue-500/20 text-blue-400 rounded-lg text-sm"><Edit className="w-3 h-3" />Edit</button>
                <button onClick={() => handleDelete(student._id)} className="flex-1 flex items-center justify-center gap-1 px-3 py-1.5 bg-red-500/20 text-red-400 rounded-lg text-sm"><Trash2 className="w-3 h-3" />Hapus</button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {isModalOpen && (
        <Modal title={editingStudent ? 'Edit Siswa' : 'Tambah Siswa'} onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><label className="block text-sm text-gray-300 mb-1">Nama Lengkap</label><input type="text" value={formData.fullName} onChange={(e) => setFormData({ ...formData, fullName: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" required /></div>
            <div><label className="block text-sm text-gray-300 mb-1">Quote</label><textarea value={formData.quote} onChange={(e) => setFormData({ ...formData, quote: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" rows={2} required /></div>
            <div><label className="block text-sm text-gray-300 mb-1">Foto {editingStudent && '(kosongkan jika tidak mengubah)'}</label><input type="file" accept="image/*" onChange={(e) => setFormData({ ...formData, photo: e.target.files?.[0] || null })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" {...(!editingStudent && { required: true })} /></div>
            <div className="flex gap-2 pt-4"><button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-white/5 rounded-lg text-white">Batal</button><button type="submit" className="flex-1 px-4 py-2 bg-blue-500 rounded-lg text-white">Simpan</button></div>
          </form>
        </Modal>
      )}
    </div>
  );
};

const TeacherTab: React.FC = () => {
  const [teacher, setTeacher] = useState<Teacher | null>(null);
  const [formData, setFormData] = useState({ fullName: '', subject: '', quote: '', bio: '', photo: null as File | null });

  useEffect(() => { fetchTeacher(); }, []);

  const fetchTeacher = async () => {
    try {
      const response = await teacherAPI.get();
      setTeacher(response.data);
      if (response.data) setFormData({ fullName: response.data.fullName, subject: response.data.subject, quote: response.data.quote, bio: response.data.bio || '', photo: null });
    } catch (error) { toast.error('Failed to fetch teacher'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = new FormData();
    data.append('fullName', formData.fullName);
    data.append('subject', formData.subject);
    data.append('quote', formData.quote);
    if (formData.bio) data.append('bio', formData.bio);
    if (formData.photo) data.append('photo', formData.photo);
    try {
      if (teacher) await teacherAPI.update(data);
      else await teacherAPI.create(data);
      toast.success('Teacher saved');
      fetchTeacher();
    } catch (error) { toast.error('Failed to save teacher'); }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Data Wali Kelas</h2>
      <form onSubmit={handleSubmit} className="max-w-2xl space-y-4">
        {teacher?.photo && <div className="mb-4"><img src={teacher.photo} alt={teacher.fullName} className="w-32 h-32 rounded-full object-cover" /></div>}
        <div><label className="block text-sm text-gray-300 mb-1">Nama Lengkap</label><input type="text" value={formData.fullName} onChange={(e) => setFormData({ ...formData, fullName: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" required /></div>
        <div><label className="block text-sm text-gray-300 mb-1">Mata Pelajaran</label><input type="text" value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" required /></div>
        <div><label className="block text-sm text-gray-300 mb-1">Quote</label><textarea value={formData.quote} onChange={(e) => setFormData({ ...formData, quote: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" rows={2} required /></div>
        <div><label className="block text-sm text-gray-300 mb-1">Foto {teacher && '(kosongkan jika tidak mengubah)'}</label><input type="file" accept="image/*" onChange={(e) => setFormData({ ...formData, photo: e.target.files?.[0] || null })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" {...(!teacher && { required: true })} /></div>
        <button type="submit" className="px-6 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white">Simpan</button>
      </form>
    </div>
  );
};

const GalleryTab: React.FC = () => {
  const [images, setImages] = useState<GalleryItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingImage, setEditingImage] = useState<GalleryItem | null>(null);
  const [formData, setFormData] = useState({ title: '', description: '', image: null as File | null });

  useEffect(() => { fetchImages(); }, []);

  const fetchImages = async () => {
    try {
      const response = await galleryAPI.getAll();
      setImages(response.data);
    } catch (error) { toast.error('Failed to fetch images'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const data = new FormData();
    data.append('title', formData.title);
    if (formData.description) data.append('description', formData.description);
    if (formData.image) data.append('gallery', formData.image);
    try {
      if (editingImage) {
        await galleryAPI.update(editingImage._id, data);
        toast.success('Image updated');
      } else {
        await galleryAPI.create(data);
        toast.success('Image uploaded');
      }
      setIsModalOpen(false);
      setEditingImage(null);
      setFormData({ title: '', description: '', image: null });
      fetchImages();
    } catch (error) { toast.error('Failed to save image'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this image?')) return;
    try {
      await galleryAPI.delete(id);
      toast.success('Image deleted');
      fetchImages();
    } catch (error) { toast.error('Failed to delete'); }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Galeri ({images.length})</h2>
        <button onClick={() => { setEditingImage(null); setFormData({ title: '', description: '', image: null }); setIsModalOpen(true); }} className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white"><Plus className="w-4 h-4" />Upload</button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {images.map((image) => (
          <div key={image._id} className="glass rounded-xl overflow-hidden">
            <div className="aspect-square"><img src={image.image} alt={image.title} className="w-full h-full object-cover" /></div>
            <div className="p-3">
              <h3 className="font-medium text-sm mb-1 truncate">{image.title}</h3>
              <div className="flex gap-1">
                <button onClick={() => { setEditingImage(image); setFormData({ title: image.title, description: image.description || '', image: null }); setIsModalOpen(true); }} className="flex-1 p-1.5 bg-blue-500/20 text-blue-400 rounded text-xs"><Edit className="w-3 h-3 mx-auto" /></button>
                <button onClick={() => handleDelete(image._id)} className="flex-1 p-1.5 bg-red-500/20 text-red-400 rounded text-xs"><Trash2 className="w-3 h-3 mx-auto" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {isModalOpen && (
        <Modal title={editingImage ? 'Edit Foto' : 'Upload Foto'} onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><label className="block text-sm text-gray-300 mb-1">Judul</label><input type="text" value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" required /></div>
            <div><label className="block text-sm text-gray-300 mb-1">Foto {editingImage && '(kosongkan jika tidak mengubah)'}</label><input type="file" accept="image/*" onChange={(e) => setFormData({ ...formData, image: e.target.files?.[0] || null })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" {...(!editingImage && { required: true })} /></div>
            <div className="flex gap-2 pt-4"><button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-white/5 rounded-lg text-white">Batal</button><button type="submit" className="flex-1 px-4 py-2 bg-blue-500 rounded-lg text-white">Simpan</button></div>
          </form>
        </Modal>
      )}
    </div>
  );
};

const SocialTab: React.FC = () => {
  const [socials, setSocials] = useState<SocialLink[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSocial, setEditingSocial] = useState<SocialLink | null>(null);
  const [formData, setFormData] = useState({ platform: 'instagram', url: '', isActive: true });

  useEffect(() => { fetchSocials(); }, []);

  const fetchSocials = async () => {
    try {
      const response = await socialAPI.getAllAdmin();
      setSocials(response.data);
    } catch (error) { toast.error('Failed to fetch social links'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingSocial) {
        await socialAPI.update(editingSocial._id, formData);
        toast.success('Social link updated');
      } else {
        await socialAPI.create(formData);
        toast.success('Social link created');
      }
      setIsModalOpen(false);
      setEditingSocial(null);
      setFormData({ platform: 'instagram', url: '', isActive: true });
      fetchSocials();
    } catch (error: any) { toast.error(error.response?.data?.message || 'Failed to save'); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this link?')) return;
    try {
      await socialAPI.delete(id);
      toast.success('Social link deleted');
      fetchSocials();
    } catch (error) { toast.error('Failed to delete'); }
  };

  const platforms = ['instagram', 'tiktok', 'youtube', 'twitter', 'facebook'];

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Link Media Sosial</h2>
        <button onClick={() => { setEditingSocial(null); setFormData({ platform: 'instagram', url: '', isActive: true }); setIsModalOpen(true); }} className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white"><Plus className="w-4 h-4" />Tambah</button>
      </div>
      <div className="space-y-3">
        {socials.map((social) => (
          <div key={social._id} className="glass rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${social.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}><Link className="w-5 h-5" /></div>
              <div><h3 className="font-medium capitalize">{social.platform}</h3><p className="text-sm text-gray-400 truncate max-w-[200px]">{social.url}</p></div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { setEditingSocial(social); setFormData({ platform: social.platform, url: social.url, isActive: social.isActive }); setIsModalOpen(true); }} className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><Edit className="w-4 h-4" /></button>
              <button onClick={() => handleDelete(social._id)} className="p-2 bg-red-500/20 text-red-400 rounded-lg"><Trash2 className="w-4 h-4" /></button>
            </div>
          </div>
        ))}
      </div>
      {isModalOpen && (
        <Modal title={editingSocial ? 'Edit Link' : 'Tambah Link'} onClose={() => setIsModalOpen(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div><label className="block text-sm text-gray-300 mb-1">Platform</label><select value={formData.platform} onChange={(e) => setFormData({ ...formData, platform: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" disabled={!!editingSocial}>{platforms.map((p) => (<option key={p} value={p} className="bg-navy-900">{p.charAt(0).toUpperCase() + p.slice(1)}</option>))}</select></div>
            <div><label className="block text-sm text-gray-300 mb-1">URL</label><input type="url" value={formData.url} onChange={(e) => setFormData({ ...formData, url: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" required placeholder="https://..." /></div>
            <div className="flex items-center gap-2"><input type="checkbox" id="isActive" checked={formData.isActive} onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })} className="w-4 h-4 rounded border-white/10 bg-white/5" /><label htmlFor="isActive" className="text-sm text-gray-300">Aktif</label></div>
            <div className="flex gap-2 pt-4"><button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 bg-white/5 rounded-lg text-white">Batal</button><button type="submit" className="flex-1 px-4 py-2 bg-blue-500 rounded-lg text-white">Simpan</button></div>
          </form>
        </Modal>
      )}
    </div>
  );
};

const SettingsTab: React.FC = () => {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [formData, setFormData] = useState({ className: '', classDescription: '', musicTitle: '' });
  const [heroImage, setHeroImage] = useState<File | null>(null);
  const [musicFile, setMusicFile] = useState<File | null>(null);

  useEffect(() => { fetchSettings(); }, []);

  const fetchSettings = async () => {
    try {
      const response = await settingsAPI.get();
      setSettings(response.data);
      setFormData({ className: response.data.className, classDescription: response.data.classDescription, musicTitle: response.data.musicTitle });
    } catch (error) { toast.error('Failed to fetch settings'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await settingsAPI.update(formData);
      toast.success('Settings saved');
      fetchSettings();
    } catch (error) { toast.error('Failed to save settings'); }
  };

  const handleHeroImageUpload = async () => {
    if (!heroImage) return;
    const data = new FormData();
    data.append('heroImage', heroImage);
    try {
      await settingsAPI.uploadHeroImage(data);
      toast.success('Hero image uploaded');
      setHeroImage(null);
      fetchSettings();
    } catch (error) { toast.error('Failed to upload hero image'); }
  };

  const handleMusicUpload = async () => {
    if (!musicFile) return;
    const data = new FormData();
    data.append('backgroundMusic', musicFile);
    data.append('musicTitle', formData.musicTitle);
    try {
      await settingsAPI.uploadBackgroundMusic(data);
      toast.success('Music uploaded');
      setMusicFile(null);
      fetchSettings();
    } catch (error) { toast.error('Failed to upload music'); }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6">Pengaturan Website</h2>
      <form onSubmit={handleSubmit} className="space-y-4 max-w-2xl">
        <div><label className="block text-sm text-gray-300 mb-1">Nama Kelas</label><input type="text" value={formData.className} onChange={(e) => setFormData({ ...formData, className: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" /></div>
        <div><label className="block text-sm text-gray-300 mb-1">Deskripsi Kelas</label><textarea value={formData.classDescription} onChange={(e) => setFormData({ ...formData, classDescription: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" rows={3} /></div>
        <button type="submit" className="px-6 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white">Simpan</button>
      </form>

      <div className="border-t border-white/10 pt-6 mt-6">
        <h3 className="text-lg font-medium mb-4">Hero Image</h3>
        {settings?.heroImage && <div className="mb-4"><img src={settings.heroImage} alt="Hero" className="w-full max-w-md rounded-lg" /></div>}
        <div className="flex gap-2">
          <input type="file" accept="image/*" onChange={(e) => setHeroImage(e.target.files?.[0] || null)} className="flex-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:bg-blue-500 file:text-white" />
          <button onClick={handleHeroImageUpload} disabled={!heroImage} className="px-4 py-2 bg-blue-500 disabled:opacity-50 rounded-lg text-white">Upload</button>
        </div>
      </div>

      <div className="border-t border-white/10 pt-6 mt-6">
        <h3 className="text-lg font-medium mb-4">Background Music</h3>
        {settings?.backgroundMusic && (
          <div className="mb-4 p-4 glass rounded-lg flex items-center gap-3">
            <Music className="w-5 h-5 text-blue-400" />
            <div><p className="font-medium">{settings.musicTitle}</p><p className="text-sm text-gray-400">Music file uploaded</p></div>
          </div>
        )}
        <div className="space-y-3">
          <div><label className="block text-sm text-gray-300 mb-1">Judul Musik</label><input type="text" value={formData.musicTitle} onChange={(e) => setFormData({ ...formData, musicTitle: e.target.value })} className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white" /></div>
          <div className="flex gap-2">
            <input type="file" accept="audio/*" onChange={(e) => setMusicFile(e.target.files?.[0] || null)} className="flex-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:bg-blue-500 file:text-white" />
            <button onClick={handleMusicUpload} disabled={!musicFile} className="px-4 py-2 bg-blue-500 disabled:opacity-50 rounded-lg text-white">Upload</button>
          </div>
        </div>
      </div>
    </div>
  );
};

const Modal: React.FC<{ title: string; children: React.ReactNode; onClose: () => void }> = ({ title, children, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-overlay" onClick={onClose}>
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="bg-navy-900 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6">{children}</div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
