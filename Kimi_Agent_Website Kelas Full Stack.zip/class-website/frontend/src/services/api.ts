import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authAPI = {
  login: (username: string, password: string) =>
    api.post('/auth/login', { username, password }),
  getMe: () => api.get('/auth/me'),
  changePassword: (currentPassword: string, newPassword: string) =>
    api.post('/auth/change-password', { currentPassword, newPassword }),
};

export const studentsAPI = {
  getAll: () => api.get('/students'),
  getById: (id: string) => api.get(`/students/${id}`),
  create: (data: FormData) => api.post('/students', data),
  update: (id: string, data: FormData) => api.put(`/students/${id}`, data),
  delete: (id: string) => api.delete(`/students/${id}`),
};

export const teacherAPI = {
  get: () => api.get('/teacher'),
  create: (data: FormData) => api.post('/teacher', data),
  update: (data: FormData) => api.put('/teacher', data),
};

export const galleryAPI = {
  getAll: () => api.get('/gallery'),
  getById: (id: string) => api.get(`/gallery/${id}`),
  create: (data: FormData) => api.post('/gallery', data),
  update: (id: string, data: FormData) => api.put(`/gallery/${id}`, data),
  delete: (id: string) => api.delete(`/gallery/${id}`),
};

export const socialAPI = {
  getAll: () => api.get('/social'),
  getAllAdmin: () => api.get('/social/all'),
  create: (data: { platform: string; url: string; isActive?: boolean }) =>
    api.post('/social', data),
  update: (id: string, data: { platform?: string; url?: string; isActive?: boolean }) =>
    api.put(`/social/${id}`, data),
  delete: (id: string) => api.delete(`/social/${id}`),
};

export const settingsAPI = {
  get: () => api.get('/settings'),
  update: (data: {
    className?: string;
    classDescription?: string;
    primaryColor?: string;
    secondaryColor?: string;
    musicTitle?: string;
  }) => api.put('/settings', data),
  uploadHeroImage: (data: FormData) =>
    api.post('/settings/hero-image', data),
  uploadBackgroundMusic: (data: FormData) =>
    api.post('/settings/background-music', data),
  removeBackgroundMusic: () =>
    api.delete('/settings/background-music'),
};

export default api;
