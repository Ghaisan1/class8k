import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

import { AuthProvider } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BackgroundMusic from '@/components/BackgroundMusic';

import Home from '@/pages/Home';
import Students from '@/pages/Students';
import Gallery from '@/pages/Gallery';
import Login from '@/pages/Login';
import Dashboard from '@/pages/Dashboard';

import { settingsAPI } from '@/services/api';
import type { Settings } from '@/types';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const token = localStorage.getItem('token');
  if (!token) {
    window.location.href = '/login';
    return null;
  }
  return <>{children}</>;
};

function App() {
  const [settings, setSettings] = useState<Settings | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await settingsAPI.get();
      setSettings(response.data);
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  };

  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-navy-950 text-white">
          <Navbar />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/students" element={<Students />} />
              <Route path="/gallery" element={<Gallery />} />
              <Route path="/login" element={<Login />} />
              <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            </Routes>
          </main>
          <Footer />
          <BackgroundMusic musicUrl={settings?.backgroundMusic} musicTitle={settings?.musicTitle} />
          <Toaster position="top-right" toastOptions={{ duration: 3000, style: { background: '#1e3a5f', color: '#fff' } }} />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
