import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Instagram, Youtube, Twitter, Facebook, Link } from 'lucide-react';
import { socialAPI } from '@/services/api';
import type { SocialLink } from '@/types';

const TikTokIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
  </svg>
);

const SocialLinks: React.FC = () => {
  const [socials, setSocials] = useState<SocialLink[]>([]);

  useEffect(() => {
    fetchSocials();
  }, []);

  const fetchSocials = async () => {
    try {
      const response = await socialAPI.getAll();
      setSocials(response.data);
    } catch (error) {
      console.error('Error fetching socials:', error);
    }
  };

  const getIcon = (platform: string) => {
    switch (platform) {
      case 'instagram': return <Instagram className="w-5 h-5" />;
      case 'tiktok': return <TikTokIcon className="w-5 h-5" />;
      case 'youtube': return <Youtube className="w-5 h-5" />;
      case 'twitter': return <Twitter className="w-5 h-5" />;
      case 'facebook': return <Facebook className="w-5 h-5" />;
      default: return <Link className="w-5 h-5" />;
    }
  };

  if (socials.length === 0) return null;

  return (
    <div className="flex items-center gap-3">
      {socials.map((social, index) => (
        <motion.a key={social._id} href={social.url} target="_blank" rel="noopener noreferrer"
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: index * 0.1 }}
          className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-blue-500 transition-colors"
          title={social.platform}>
          {getIcon(social.platform)}
        </motion.a>
      ))}
    </div>
  );
};

export default SocialLinks;
