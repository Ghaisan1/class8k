import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, Music } from 'lucide-react';

interface BackgroundMusicProps {
  musicUrl: string | null | undefined;
  musicTitle?: string | undefined;
}

const BackgroundMusic: React.FC<BackgroundMusicProps> = ({ musicUrl, musicTitle = 'Background Music' }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (musicUrl) {
      audioRef.current = new Audio(musicUrl);
      audioRef.current.loop = true;
      audioRef.current.volume = 0.5;
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [musicUrl]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    }
  };

  if (!musicUrl) return null;

  return (
    <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
      className="fixed bottom-6 right-6 z-50">
      <div className="audio-player glass backdrop-blur-md">
        <div className="flex items-center gap-3">
          <motion.div animate={isPlaying ? { rotate: 360 } : { rotate: 0 }} transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
            <Music className="w-4 h-4 text-white" />
          </motion.div>
          <div className="hidden sm:block">
            <p className="text-xs text-gray-400">Now Playing</p>
            <p className="text-sm font-medium text-white truncate max-w-[120px]">{musicTitle}</p>
          </div>
          <button onClick={togglePlay} className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default BackgroundMusic;
