import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy-950 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
            <div className="flex items-center gap-2 mb-4">
              <GraduationCap className="w-8 h-8 text-blue-400" />
              <span className="text-xl font-bold">Class<span className="gradient-text">Website</span></span>
            </div>
            <p className="text-gray-400 text-sm">Website kelas yang dibuat dengan penuh cinta dan dedikasi.</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }}>
            <h3 className="text-lg font-semibold mb-4">Tautan Cepat</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-400 hover:text-white text-sm">Beranda</a></li>
              <li><a href="/students" className="text-gray-400 hover:text-white text-sm">Daftar Siswa</a></li>
              <li><a href="/gallery" className="text-gray-400 hover:text-white text-sm">Galeri</a></li>
            </ul>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }}>
            <h3 className="text-lg font-semibold mb-4">Kontak</h3>
            <p className="text-gray-400 text-sm">Hubungi kami melalui media sosial yang tersedia.</p>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.3 }}
          className="mt-12 pt-8 border-t border-white/5 text-center">
          <p className="text-gray-400 text-sm flex items-center justify-center gap-1 flex-wrap">
            Website developed by <span className="text-blue-400 font-medium">Ghaisan Athaillah Fuadi</span>
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
          </p>
          <p className="text-gray-500 text-xs mt-2">&copy; {currentYear} Class Website. All rights reserved.</p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
