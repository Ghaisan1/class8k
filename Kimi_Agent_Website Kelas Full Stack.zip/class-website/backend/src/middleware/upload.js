const multer = require('multer');
const path = require('path');

// Configure storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let uploadPath = 'uploads/';
    
    if (file.fieldname === 'photo' || file.fieldname === 'image') {
      uploadPath += 'students/';
    } else if (file.fieldname === 'gallery') {
      uploadPath += 'gallery/';
    } else if (file.fieldname === 'heroImage') {
      uploadPath += 'hero/';
    } else if (file.fieldname === 'backgroundMusic') {
      uploadPath += 'music/';
    }
    
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  const allowedImageTypes = /jpeg|jpg|png|webp|gif/;
  const allowedAudioTypes = /mp3|wav|ogg|m4a/;
  
  const extname = path.extname(file.originalname).toLowerCase();
  const mimetype = file.mimetype;
  
  if (file.fieldname === 'photo' || file.fieldname === 'image' || file.fieldname === 'gallery' || file.fieldname === 'heroImage') {
    // Accept images only
    if (allowedImageTypes.test(extname) && allowedImageTypes.test(mimetype)) {
      return cb(null, true);
    }
    return cb(new Error('Only image files are allowed (jpeg, jpg, png, webp, gif)'));
  } else if (file.fieldname === 'backgroundMusic') {
    // Accept audio only
    if (allowedAudioTypes.test(extname) || mimetype.startsWith('audio/')) {
      return cb(null, true);
    }
    return cb(new Error('Only audio files are allowed (mp3, wav, ogg, m4a)'));
  }
  
  cb(null, true);
};

// Configure multer
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

module.exports = upload;
