const express = require('express');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
require('dotenv').config();

const connectDB = require('./config/db');

// Import routes
const authRoutes = require('./routes/auth');
const studentRoutes = require('./routes/students');
const teacherRoutes = require('./routes/teacher');
const galleryRoutes = require('./routes/gallery');
const socialRoutes = require('./routes/social');
const settingsRoutes = require('./routes/settings');

// Import models for seeding
const { Admin, Student, Teacher, Social, Settings } = require('./models');
const seedStudents = require('./utils/seedData');

const app = express();

// Connect to database
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/teacher', teacherRoutes);
app.use('/api/gallery', galleryRoutes);
app.use('/api/social', socialRoutes);
app.use('/api/settings', settingsRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Server is running' });
});

// Seed initial data
const seedData = async () => {
  try {
    // Create default admin if not exists
    const adminExists = await Admin.findOne({ username: 'admin' });
    if (!adminExists) {
      await Admin.create({
        username: 'admin',
        password: 'admin123'
      });
      console.log('Default admin created: username=admin, password=admin123');
    }

    // Create default settings if not exists
    await Settings.getSettings();

    // Create default social links if not exists
    const socialPlatforms = [
      { platform: 'instagram', url: 'https://instagram.com' },
      { platform: 'tiktok', url: 'https://tiktok.com' },
      { platform: 'youtube', url: 'https://youtube.com' }
    ];

    for (const social of socialPlatforms) {
      const exists = await Social.findOne({ platform: social.platform });
      if (!exists) {
        await Social.create(social);
      }
    }

    console.log('Seed data completed');
    
    // Seed students and teacher
    await seedStudents();
  } catch (error) {
    console.error('Seed error:', error);
  }
};

// Run seed after DB connection
setTimeout(seedData, 2000);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ message: 'File size too large (max 10MB)' });
    }
  }
  res.status(500).json({ message: err.message || 'Something went wrong!' });
});

// Handle 404
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
