const mongoose = require('mongoose');

const teacherSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
    trim: true
  },
  photo: {
    type: String,
    required: true
  },
  subject: {
    type: String,
    required: true
  },
  quote: {
    type: String,
    required: true,
    maxlength: 300
  },
  bio: {
    type: String,
    maxlength: 1000
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Teacher', teacherSchema);
