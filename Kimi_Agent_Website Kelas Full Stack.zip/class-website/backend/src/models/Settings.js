const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  className: {
    type: String,
    default: 'Kelas XII IPA 1'
  },
  classDescription: {
    type: String,
    default: 'Selamat datang di website kelas kami'
  },
  heroImage: {
    type: String,
    default: null
  },
  heroVideo: {
    type: String,
    default: null
  },
  backgroundMusic: {
    type: String,
    default: null
  },
  musicTitle: {
    type: String,
    default: 'Background Music'
  },
  primaryColor: {
    type: String,
    default: '#1e3a5f'
  },
  secondaryColor: {
    type: String,
    default: '#0f172a'
  }
}, {
  timestamps: true
});

// Ensure only one settings document exists
settingsSchema.statics.getSettings = async function() {
  let settings = await this.findOne();
  if (!settings) {
    settings = await this.create({});
  }
  return settings;
};

module.exports = mongoose.model('Settings', settingsSchema);
