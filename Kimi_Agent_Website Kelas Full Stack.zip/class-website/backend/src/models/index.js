const Admin = require('./Admin');
const Student = require('./Student');
const Teacher = require('./Teacher');
const Gallery = require('./Gallery');
const Social = require('./Social');
const Settings = require('./Settings');

module.exports = {
  Admin,
  Student,
  Teacher,
  Gallery,
  Social,
  Settings
};
