const mongoose = require('mongoose');
const { Student, Teacher, Admin, Settings, Social } = require('../models');

const sampleStudents = [
  { fullName: 'Ahmad Rizky', quote: 'Belajar adalah investasi terbaik untuk masa depan.' },
  { fullName: 'Budi Santoso', quote: 'Kesuksesan datang dari kerja keras dan doa.' },
  { fullName: 'Citra Lestari', quote: 'Impian besar membutuhkan usaha besar.' },
  { fullName: 'Dewi Anggraini', quote: 'Setiap hari adalah kesempatan baru untuk belajar.' },
  { fullName: 'Eko Prasetyo', quote: 'Jangan takut gagal, takutlah untuk tidak mencoba.' },
  { fullName: 'Fani Rahmawati', quote: 'Kebersamaan membuat perjalanan lebih indah.' },
  { fullName: 'Gita Permata', quote: 'Tetap rendah hati meski sudah sukses.' },
  { fullName: 'Hadi Wijaya', quote: 'Disiplin adalah kunci keberhasilan.' },
  { fullName: 'Indah Sari', quote: 'Kebaikan akan kembali pada kita.' },
  { fullName: 'Joko Susilo', quote: 'Kerja sama tim menghasilkan prestasi gemilang.' },
  { fullName: 'Kartika Dewi', quote: 'Percaya diri adalah modal utama.' },
  { fullName: 'Lutfi Hakim', quote: 'Ilmu adalah cahaya yang menerangi jalan.' },
  { fullName: 'Maya Indriani', quote: 'Jadilah versi terbaik dari dirimu.' },
  { fullName: 'Nanda Putra', quote: 'Kegagalan adalah guru terbaik.' },
  { fullName: 'Olivia Tan', quote: 'Kreativitas tanpa batas.' },
  { fullName: 'Putra Wibowo', quote: 'Bersyukur dalam setiap keadaan.' },
  { fullName: 'Qori Andini', quote: 'Ketekunan mengalahkan bakat.' },
  { fullName: 'Raka Mahendra', quote: 'Bermimpi besar, beraksi lebih besar.' },
  { fullName: 'Salsa Nabila', quote: 'Keindahan hidup ada dalam proses.' },
  { fullName: 'Tegar Pratama', quote: 'Tetap kuat meski dihadang rintangan.' },
  { fullName: 'Uli Amalia', quote: 'Cinta pada ilmu mengubah hidup.' },
  { fullName: 'Vino Ardiansyah', quote: 'Inovasi adalah kunci kemajuan.' },
  { fullName: 'Wulan Sari', quote: 'Kesabaran menghasilkan hasil terbaik.' },
  { fullName: 'Xavier Lim', quote: 'Berpikir positif, hidup positif.' },
  { fullName: 'Yani Kusuma', quote: 'Setiap masalah ada solusinya.' },
  { fullName: 'Zaki Maulana', quote: 'Kejujuran adalah dasar kehidupan.' },
  { fullName: 'Adinda Putri', quote: 'Kekuatan wanita tak terbatas.' },
  { fullName: 'Bagas Arya', quote: 'Tanggung jawab adalah tanda dewasa.' },
  { fullName: 'Cindy Marcelina', quote: 'Kehangatan keluarga adalah segalanya.' },
  { fullName: 'Dafa Ramadhan', quote: 'Puasa mengajarkan kesabaran.' },
  { fullName: 'Elisa Oktaviani', quote: 'Musik adalah bahasa universal.' },
  { fullName: 'Farel Nugroho', quote: 'Olahraga membuat tubuh sehat.' },
  { fullName: 'Ghani Fauzan', quote: 'Teknologi adalah masa depan.' },
  { fullName: 'Hana Fatimah', quote: 'Keindahan ada dalam kesederhanaan.' },
  { fullName: 'Iqbal Maulana', quote: 'Pemikiran kritis membuka wawasan.' },
  { fullName: 'Jelita Ananda', quote: 'Kebahagiaan datang dari diri sendiri.' },
  { fullName: 'Kevin Alvaro', quote: 'Persahabatan adalah harta karun.' },
  { fullName: 'Lia Oktaria', quote: 'Membaca membuka dunia baru.' },
  { fullName: 'Mikhael Juan', quote: 'Ketekunan mengalahkan segalanya.' },
  { fullName: 'Nabila Azzahra', quote: 'Kebaikan hati menarik kebaikan.' },
];

const seedData = async () => {
  try {
    // Check if students already exist
    const existingStudents = await Student.countDocuments();
    if (existingStudents > 0) {
      console.log('Students already seeded');
      return;
    }

    console.log('Seeding students...');
    
    // Create students with placeholder photos
    for (let i = 0; i < sampleStudents.length; i++) {
      const student = sampleStudents[i];
      await Student.create({
        fullName: student.fullName,
        quote: student.quote,
        photo: `https://ui-avatars.com/api/?name=${encodeURIComponent(student.fullName)}&background=random&color=fff&size=256`,
        order: i,
      });
    }
    
    console.log(`${sampleStudents.length} students created successfully`);

    // Create teacher if not exists
    const existingTeacher = await Teacher.findOne();
    if (!existingTeacher) {
      await Teacher.create({
        fullName: 'Ibu Sarah Wulandari, S.Pd.',
        subject: 'Matematika',
        quote: 'Setiap anak adalah bintang yang bersinar dengan caranya sendiri. Saya bangga menjadi bagian dari perjalanan kalian.',
        bio: 'Wali kelas yang penuh kasih sayang dan dedikasi. Selalu mendukung setiap siswa untuk mencapai potensi terbaiknya.',
        photo: 'https://ui-avatars.com/api/?name=Sarah+Wulandari&background=1e3a5f&color=fff&size=256',
      });
      console.log('Teacher created successfully');
    }

    console.log('Seeding completed!');
  } catch (error) {
    console.error('Seeding error:', error);
  }
};

module.exports = seedData;
