const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Social = require('../models/Social');
const authMiddleware = require('../middleware/auth');

// @route   GET /api/social
// @desc    Get all active social links
// @access  Public
router.get('/', async (req, res) => {
  try {
    const socials = await Social.find({ isActive: true }).sort({ createdAt: 1 });
    res.json(socials);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   GET /api/social/all
// @desc    Get all social links (including inactive) - Admin only
// @access  Private
router.get('/all', authMiddleware, async (req, res) => {
  try {
    const socials = await Social.find().sort({ createdAt: 1 });
    res.json(socials);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/social
// @desc    Add new social link
// @access  Private
router.post('/', [
  authMiddleware,
  body('platform').isIn(['instagram', 'tiktok', 'youtube', 'twitter', 'facebook']).withMessage('Invalid platform'),
  body('url').isURL().withMessage('Valid URL is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { platform, url, isActive } = req.body;

    // Check if platform already exists
    const existingSocial = await Social.findOne({ platform });
    if (existingSocial) {
      return res.status(400).json({ message: 'Social platform already exists. Use PUT to update.' });
    }

    const social = new Social({
      platform,
      url,
      isActive: isActive !== undefined ? isActive : true
    });

    await social.save();
    res.status(201).json(social);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/social/:id
// @desc    Update social link
// @access  Private
router.put('/:id', [
  authMiddleware,
  body('platform').optional().isIn(['instagram', 'tiktok', 'youtube', 'twitter', 'facebook']).withMessage('Invalid platform'),
  body('url').optional().isURL().withMessage('Valid URL is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { platform, url, isActive } = req.body;
    const updateData = { platform, url, isActive };

    // Remove undefined fields
    Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);

    const social = await Social.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    if (!social) {
      return res.status(404).json({ message: 'Social link not found' });
    }

    res.json(social);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/social/:id
// @desc    Delete social link
// @access  Private
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const social = await Social.findByIdAndDelete(req.params.id);
    if (!social) {
      return res.status(404).json({ message: 'Social link not found' });
    }
    res.json({ message: 'Social link deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
