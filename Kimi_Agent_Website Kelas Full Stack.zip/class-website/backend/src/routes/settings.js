const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Settings = require('../models/Settings');
const authMiddleware = require('../middleware/auth');
const upload = require('../middleware/upload');

// @route   GET /api/settings
// @desc    Get website settings
// @access  Public
router.get('/', async (req, res) => {
  try {
    const settings = await Settings.getSettings();
    res.json(settings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/settings
// @desc    Update website settings
// @access  Private
router.put('/', [
  authMiddleware,
  body('className').optional().trim().notEmpty().withMessage('Class name cannot be empty'),
  body('classDescription').optional().trim().notEmpty().withMessage('Description cannot be empty')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { className, classDescription, primaryColor, secondaryColor, musicTitle } = req.body;
    const updateData = { className, classDescription, primaryColor, secondaryColor, musicTitle };

    // Remove undefined fields
    Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);

    const settings = await Settings.getSettings();
    const updatedSettings = await Settings.findByIdAndUpdate(
      settings._id,
      updateData,
      { new: true }
    );

    res.json(updatedSettings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/settings/hero-image
// @desc    Upload hero image
// @access  Private
router.post('/hero-image', [
  authMiddleware,
  upload.single('heroImage')
], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Image file is required' });
    }

    const settings = await Settings.getSettings();
    const updatedSettings = await Settings.findByIdAndUpdate(
      settings._id,
      { heroImage: `/uploads/hero/${req.file.filename}`, heroVideo: null },
      { new: true }
    );

    res.json(updatedSettings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/settings/background-music
// @desc    Upload background music
// @access  Private
router.post('/background-music', [
  authMiddleware,
  upload.single('backgroundMusic')
], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Audio file is required' });
    }

    const { musicTitle } = req.body;
    const settings = await Settings.getSettings();
    
    const updateData = { 
      backgroundMusic: `/uploads/music/${req.file.filename}` 
    };
    
    if (musicTitle) {
      updateData.musicTitle = musicTitle;
    }

    const updatedSettings = await Settings.findByIdAndUpdate(
      settings._id,
      updateData,
      { new: true }
    );

    res.json(updatedSettings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   DELETE /api/settings/background-music
// @desc    Remove background music
// @access  Private
router.delete('/background-music', authMiddleware, async (req, res) => {
  try {
    const settings = await Settings.getSettings();
    const updatedSettings = await Settings.findByIdAndUpdate(
      settings._id,
      { backgroundMusic: null, musicTitle: 'Background Music' },
      { new: true }
    );

    res.json(updatedSettings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
