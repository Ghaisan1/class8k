const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Teacher = require('../models/Teacher');
const authMiddleware = require('../middleware/auth');
const upload = require('../middleware/upload');

// @route   GET /api/teacher
// @desc    Get teacher (wali kelas)
// @access  Public
router.get('/', async (req, res) => {
  try {
    const teacher = await Teacher.findOne();
    res.json(teacher);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   POST /api/teacher
// @desc    Create or update teacher
// @access  Private
router.post('/', [
  authMiddleware,
  upload.single('photo'),
  body('fullName').trim().notEmpty().withMessage('Full name is required'),
  body('subject').trim().notEmpty().withMessage('Subject is required'),
  body('quote').trim().notEmpty().withMessage('Quote is required')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { fullName, subject, quote, bio } = req.body;

    // Check if teacher already exists
    let teacher = await Teacher.findOne();

    const teacherData = {
      fullName,
      subject,
      quote,
      bio,
      ...(req.file && { photo: `/uploads/students/${req.file.filename}` })
    };

    if (teacher) {
      // Update existing
      teacher = await Teacher.findByIdAndUpdate(
        teacher._id,
        teacherData,
        { new: true }
      );
    } else {
      // Create new
      teacher = new Teacher(teacherData);
      await teacher.save();
    }

    res.json(teacher);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

// @route   PUT /api/teacher
// @desc    Update teacher
// @access  Private
router.put('/', [
  authMiddleware,
  upload.single('photo'),
  body('fullName').optional().trim().notEmpty().withMessage('Full name cannot be empty'),
  body('subject').optional().trim().notEmpty().withMessage('Subject cannot be empty'),
  body('quote').optional().trim().notEmpty().withMessage('Quote cannot be empty')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { fullName, subject, quote, bio } = req.body;
    const updateData = { fullName, subject, quote, bio };

    if (req.file) {
      updateData.photo = `/uploads/students/${req.file.filename}`;
    }

    // Remove undefined fields
    Object.keys(updateData).forEach(key => updateData[key] === undefined && delete updateData[key]);

    let teacher = await Teacher.findOne();
    if (!teacher) {
      return res.status(404).json({ message: 'Teacher not found' });
    }

    teacher = await Teacher.findByIdAndUpdate(
      teacher._id,
      updateData,
      { new: true }
    );

    res.json(teacher);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
